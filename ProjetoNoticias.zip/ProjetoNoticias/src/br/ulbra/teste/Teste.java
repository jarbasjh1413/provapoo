/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.teste;

import br.ulbra.connection.ConnectionFactory;
import br.ulbra.model.bean.Noticias;
import br.ulbra.model.dao.NoticiasDAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;


/**
 *
 * @author Jarbas
 */
public class Teste {

       public static void main(String[] args) {
        Noticias c = new Noticias();//instanciando objeto c
       
        c.setNoticias(JOptionPane.showInputDialog("Insira a Noticia"));
        c.setTitulo(JOptionPane.showInputDialog("Titulo da Noticia"));
        c.setDataPublicacao(JOptionPane.showInputDialog("Data de Publicação"));
        
        NoticiasDAO dao = new NoticiasDAO();
        dao.save(c);
        System.out.println("ITEM INSERIDO");
        System.out.println("Código: "+c.getId());
        System.out.println("Titulo: "+c.getTitulo());
        System.out.println("Noticia: "+c.getNoticias());
        System.out.println("Data de publicação: "+c.getDataPublicacao());
        
       String resultado = "Consulta por Noticia\n --------------------------------\n "
       +"Código  |                    Titulo                   |                    Noticia                    |  Data de publicação  \n";
        for (Noticias c1: dao.findAll()){resultado += "     "   +c1.getId()+   "                    "   +c1.getTitulo()+   "                    "   +c1.getNoticias()+   "                  "+c1.getDataPublicacao()+"\n";
        }
           JOptionPane.showMessageDialog(null, resultado);

         int cod = Integer.parseInt(JOptionPane.showInputDialog("Qual código deseja excluir?"));
        dao.remove(cod);
    
        
        
       

}
}



    



